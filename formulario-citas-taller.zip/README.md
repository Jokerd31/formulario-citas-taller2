# Formulario de Citas - Taller

Este repositorio contiene un formulario online para solicitar citas en el taller.  
Se puede acceder vía GitHub Pages en:  

https://jokerd31.github.io/formulario-citas-taller

## Cómo funciona

- Los clientes completan el formulario.  
- Cada envío genera un archivo Excel (`citas_taller.xlsx`) con los datos de las citas.  
- Se puede gestionar el estado de las citas y duración estimada para planificar el taller.
